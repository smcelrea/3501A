#include "enemies.h"


namespace game {

Enemies::Enemies(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture, int s) : SceneNode(name, geometry, material, texture) {
	
	state = 1;
	type = s;
	/*
		1 = normal
		2 = tanky
		3 = speedy
		4 = building
	*/if (type == 1) {
		maxHealth = 200;
		maxVel = 0.8;
	}else if (type == 2) {
		maxHealth= 1000;
		maxVel = 1.0;
	}
	else if (type == 3) {
		maxHealth = 500;
		maxVel = 1.3;
	}else{
		maxHealth = 2000;
	}
	

	health = maxHealth;
	velocity_ = glm::vec3(0.0,0.0,0.0);
	target_ = NULL;
}


Enemies::~Enemies(){
}

glm::quat Enemies::GetAngM(void) const {

    return angm_;
}

SceneNode* Enemies::GetTarget(void) const {
	return target_;
}

bool Enemies::GetCanfire(void) const {
	return canfire;
}

int Enemies::GetType(void) const {
	return type;
}

void Enemies::SetAngM(glm::quat angm){

    angm_ = angm;
}

void Enemies::SetTarget(SceneNode* target) {
	target_ = target;
}

void Enemies::ResetFire() {
	bulletlast = glfwGetTime();
	canfire = false;
}


//Was hit flag
bool Enemies::enemyHit() {
	return wasHit;
}
void Enemies::setEnemyHit(bool r) {
	wasHit = r;
}


void Enemies::Update() {
	double time = glfwGetTime();
	// ENEMY STATE LOGIC
	//Target is the state when the enemy is within a certain range of the player or was hit by a bullet
	if (glm::distance(position_, target_->GetPosition()) < 20+type*5
		|| wasHit&& glm::distance(position_, target_->GetPosition()) < 70-type*5) {
		state = 1;
	}
	else {
		//Wander is default state
		state = 3;
		if ((time - last) >= 3.0 || glm::distance(targetPos,position_) <= 0.5) {
			targetPos = glm::vec3(((float)rand()/RAND_MAX) * 250.0 - 125.0, 0.5, ((float)rand()/RAND_MAX)* 250.0 - 125.0);
			last = time;
		}
	}

	//Flee is the state when the enemy is at low hp
	if (health <= maxHealth/4) {
		state = 2;
	}

	//Dead state means the enemy has no hp left
	if (health <= 0) {
		state = 4;
		display = false;
	}

	// END ENEMY STATE LOGIC
	// Enemy Fire delay
	if (time - bulletlast >= 0.35) {
		canfire = true;
	}

	//ENEMY STEERING BEHAVIORS
	if (state == 1 && target_ && glm::length(velocity_) < maxVel) {
		// Target
		float targAng = atan2f(target_->GetPosition().z - position_.z, target_->GetPosition().x - position_.x);
		velocity_ += glm::vec3(
			cos(targAng) * 0.005,
			0.0,
			sin(targAng) * 0.005
		);
		
	}
	else if (state == 2 && target_ && glm::length(velocity_) < maxVel) {
		// Flee
		float targAng = atan2f(position_.z - target_->GetPosition().z, position_.x - target_->GetPosition().x);
		velocity_ += glm::vec3(
			cos(targAng) * 0.005,
			0.0,
			sin(targAng) * 0.005
		);
	}
	else if (state == 3 && glm::length(velocity_) < maxVel) {
		//Wander WIP
		float targAng = atan2f(targetPos.z - position_.z, targetPos.x - position_.x);
		velocity_ += glm::vec3(
			cos(targAng) * 0.005,
			0,
			sin(targAng) * 0.005
		);
	}
	else if (state == 4) {
		//Dead WIP
		//std::cout << "DEAD" << std::endl;
		velocity_ = glm::vec3(
			0,
			0,
			0
		);
	}
	// END ENEMY STEERING BEHAVIORS

	//std::cout << targetPos.x << ", " << targetPos.z << std::endl;
	//std::cout << "Health: " << name_ << "  " <<  health << std::endl;
	//std::cout << "Enemy State: " << state << std::endl;
	if (position_.y > scale_.y / 2.0f) {
		velocity_.y += 9.80 / 20.0f;
	}

	if (type != 4) {
		position_.x += velocity_.x;
		position_.z += velocity_.z;
	}
	velocity_ *= 0.9;

	if (position_.y < scale_.y / 2.0f) {
		position_.y = scale_.y / 2.0f;
	}
	Rotate(angm_);
}



} // namespace game

