Up arrow to shoot

Controls: 

Mouse: aim camera
W: Tilt and move forward 
S: Tilt and move backward 
A: Roll Left
D: Roll Right
Shift: Fly down 
Space: Fly up 
V: Toggle First/Thirdperson 
Left Click: Fire bullets
Right Click: Fire rockets
Middle Mouse: Fire homing missile
Q: pause the game

Resources:
Camouflage Textures from TF2 source files courteousy of Valve

Crumpled: 
https://freestocktextures.com/texture/shiny-silver-metallic-paper,1038.html 

Skybox: 
https://tf2maps.net/threads/sky_sunset_04-sky_iron_04.23416/ 

Cockpit: 
http://www.aljanh.net/the-cockpit-of-a-spaceship-wallpapers/3634880787.html 

Tower: 
https://opengameart.org/content/mage-tower