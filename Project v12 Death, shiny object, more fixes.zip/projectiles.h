#ifndef PROJECTILE_H_
#define PROJECTILE_H_

#include <string>
#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#define GLM_FORCE_RADIANS
#include <glm/gtc/quaternion.hpp>

#include "resource.h"
#include "scene_node.h"

namespace game {

    // Abstraction of an asteroid
    class Projectile : public SceneNode {

        public:
            // Create asteroid from given resources
			Projectile(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture, SceneNode *s);

            // Destructor
            ~Projectile();
            
            // Get/set attributes specific to asteroids
            glm::quat GetAngM(void) const;
			int getDuration();
			bool getShoot();
			int GetType(void) const;
			SceneNode *GetTarget(void) const;
			
			void setDuration(int x);
			void SetAngM(glm::quat angm);
			void setShoot(bool b);
			void SetType(int t);
			void SetTarget(SceneNode *tar);

            // Update geometry configuration
            void Update(void);

			//
			void reset();

			//
			SceneNode* getShooter() const{ return shooter; }
            
        private:
            // Angular momentum of asteroid
			SceneNode *shooter;
			SceneNode *target;
            glm::quat angm_;
			int duration;
			int type = 0;
			int state = 0;
			bool shoot;
    }; // class Asteroid

} // namespace game

#endif // PROJECTILE_H_
