#include <iostream>
#include <time.h>
#include <sstream>

#include "game.h"
#include "bin/path_config.h"

namespace game {

// Some configuration constants
// They are written here as global variables, but ideally they should be loaded from a configuration file

// Main window settings
const std::string window_title_g = "Project";
const unsigned int window_width_g = 800;
const unsigned int window_height_g = 600;
const bool window_full_screen_g = false;

// Viewport and camera settings
float camera_near_clip_distance_g = 0.01;
float camera_far_clip_distance_g = 1000.0;
float camera_fov_g = 25.0; // Field-of-view of camera
const glm::vec3 viewport_background_color_g(1.0, 1.0, 1.0);
glm::vec3 camera_position_g(0.0, 0.0, -1.0);
glm::vec3 camera_look_at_g(0.0, 0.0, 0.0);
glm::vec3 camera_up_g(0.0, 1.0, 0.0);

// Materials 
const std::string material_directory_g = MATERIAL_DIRECTORY;


Game::Game(void){

    // Don't do work in the constructor, leave it for the Init() function
}


void Game::Init(void){

    // Run all initialization steps
    InitWindow();
    InitView();
    InitEventHandlers();
	std::srand(std::time(nullptr));
    // Set variables
    animating_ = true;
	std::string keymap[] = { "w", "a", "s", "d", " ", "lshift", "lctrl" , "left", "right", "v", "F4", "up","down" };
	for (int i = 0; i < sizeof(keymap) / sizeof(*keymap); i++) {
		keys.insert(std::pair<std::string, bool> (keymap[i], false));
	}
}

       
void Game::InitWindow(void){

    // Initialize the window management library (GLFW)
    if (!glfwInit()){
        throw(GameException(std::string("Could not initialize the GLFW library")));
    }

    // Create a window and its OpenGL context
    if (window_full_screen_g){
        window_ = glfwCreateWindow(window_width_g, window_height_g, window_title_g.c_str(), glfwGetPrimaryMonitor(), NULL);
    } else {
        window_ = glfwCreateWindow(window_width_g, window_height_g, window_title_g.c_str(), NULL, NULL);
    }
    if (!window_){
        glfwTerminate();
        throw(GameException(std::string("Could not create window")));
    }

    // Make the window's context the current one
    glfwMakeContextCurrent(window_);

    // Initialize the GLEW library to access OpenGL extensions
    // Need to do it after initializing an OpenGL context
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (err != GLEW_OK){
        throw(GameException(std::string("Could not initialize the GLEW library: ")+std::string((const char *) glewGetErrorString(err))));
    }
}


void Game::InitView(void){

    // Set up z-buffer
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Set viewport
    int width, height;
    glfwGetFramebufferSize(window_, &width, &height);
    glViewport(0, 0, width, height);

    // Set up camera
    // Set current view
    camera_.SetView(camera_position_g, camera_look_at_g, camera_up_g);
	GUIcamera_.SetView(camera_position_g, camera_look_at_g, camera_up_g);
    // Set projection
    camera_.SetProjection(camera_fov_g, camera_near_clip_distance_g, camera_far_clip_distance_g, width, height);
	GUIcamera_.SetProjection(camera_fov_g, camera_near_clip_distance_g, camera_far_clip_distance_g, width, height);
}


void Game::InitEventHandlers(void){

    // Set event callbacks
    glfwSetKeyCallback(window_, KeyCallback);
    glfwSetFramebufferSizeCallback(window_, ResizeCallback);

    // Set pointer to game object, so that callbacks can access it
    glfwSetWindowUserPointer(window_, (void *) this);
}


void Game::SetupResources(void){

	SetupLoading(30);

    // Create meshes
	//resman_.CreateCube("CubeMesh");
    resman_.CreateTorus("TorusMesh");
	ProgressLoading(1);
	resman_.CreateCylinder("CylinderMesh");
	ProgressLoading(1);

	// Create particles
	resman_.CreateSphereParticles("SphereParticles");
	ProgressLoading(1);
	resman_.CreateTorusParticles("TorusParticles");
	ProgressLoading(1);
	resman_.CreateConeParticles("ConeParticles");
	ProgressLoading(1);

    // MATERIALS ------------------------------------------------------------------------------//
    //std::string filename = std::string(MATERIAL_DIRECTORY) + std::string("/three-term_shiny_blue");
	std::string filename = std::string(MATERIAL_DIRECTORY) + std::string("/three-term_textured");
    resman_.LoadResource(Material, "3TTexturedMaterial", filename.c_str());
	ProgressLoading(1);

	filename = std::string(MATERIAL_DIRECTORY) + std::string("/metal");
	resman_.LoadResource(Material, "ShinyBlueMetal", filename.c_str());
	ProgressLoading(1);

	filename = std::string(MATERIAL_DIRECTORY) + std::string("/plastic");
	resman_.LoadResource(Material, "PlasticMaterial", filename.c_str());
	ProgressLoading(1);

	filename = std::string(MATERIAL_DIRECTORY) + std::string("/three-term_toon");
	resman_.LoadResource(Material, "ToonMaterial", filename.c_str());
	ProgressLoading(1);

	// Load material for first screen-space effect
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/screen_space");
	resman_.LoadResource(Material, "ScreenSpaceMaterial", filename.c_str());
	ProgressLoading(1);

	// Load material for skybox
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/skybox");
	resman_.LoadResource(Material, "SkyboxMaterial", filename.c_str());
	ProgressLoading(1);
	
	// Load particle materials
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/fire");
	resman_.LoadResource(Material, "FireMaterial", filename.c_str());
	ProgressLoading(1);

	filename = std::string(MATERIAL_DIRECTORY) + std::string("/particle");
	resman_.LoadResource(Material, "ParticleMaterial", filename.c_str());
	ProgressLoading(1);

	// TEXTURES ------------------------------------------------------------------------------//
    // Load texture to be applied to the cube
    filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/randomspace.png");
    resman_.LoadResource(Texture, "Space", filename.c_str());
	ProgressLoading(1);

	// Load texture to be applied to the cube
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/crumpled.png");
	resman_.LoadResource(Texture, "Crumpled", filename.c_str());
	ProgressLoading(1);

	// Load texture to be applied to the cube
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/camo_jungle_grey.bmp");
	resman_.LoadResource(Texture, "Greycamo", filename.c_str());
	ProgressLoading(1);

	// Load texture to be applied to the cube
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/camo_sticky_01_blue.bmp");
	resman_.LoadResource(Texture, "Bluecamo", filename.c_str());
	ProgressLoading(1);

	// Load texture to be applied to the cube
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/powerhouse_electric_green.bmp");
	resman_.LoadResource(Texture, "GreenEl", filename.c_str());
	ProgressLoading(1);

	// Load texture to be applied to the cube
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/checker.png");
	resman_.LoadResource(Texture, "Checker", filename.c_str());
	ProgressLoading(1);

	// Load texture to be applied to the cube
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/536115016_stars.bmp");
	resman_.LoadResource(Texture, "Stars", filename.c_str());
	ProgressLoading(1);

	// Load texture to be applied to the cube
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/536115016.bmp");
	resman_.LoadResource(Texture, "Stripes", filename.c_str());
	ProgressLoading(1);

	// Load texture for tower
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/tower_uv.png");
	resman_.LoadResource(Texture, "TowerTexture", filename.c_str());
	ProgressLoading(1);

	// Load GUI elements
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/continue.png");
	resman_.LoadResource(Texture, "GUIContinue", filename.c_str());
	ProgressLoading(1);

	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/cockpit.png");
	resman_.LoadResource(Texture, "GUICockpit", filename.c_str());
	ProgressLoading(1);

	// Particle texture
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/flame4x4orig.png");
	resman_.LoadResource(Texture, "Flame", filename.c_str());

	// CUBEMAPS ------------------------------------------------------------------------------//
	// Load cube map to be applied to skybox
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/cubemaps/goldrushlight2.png");
	resman_.LoadResource(SingleCubeMap, "SkyLightTex", filename.c_str());
	ProgressLoading(1);

	// Load cube map to be applied to skybox
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/cubemaps/goldrush.png");
	resman_.LoadResource(SingleCubeMap, "SkyboxTex", filename.c_str());
	ProgressLoading(1);

	// Setup drawing to texture
	scene_.SetupDrawToTexture();
	ProgressLoading(1);

	// MESHES ------------------------------------------------------------------------------//


	// Load sphere mesh
	resman_.CreateSphere("SimpleSphereMesh", 1, 20, 20);
	ProgressLoading(1);

	// Load a cube from an obj file
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/models/cube.obj");
	resman_.LoadResource(Mesh, "CubeMesh", filename.c_str());
	ProgressLoading(1);

	// Load a Tower from an obj file
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/models/tower.obj");
	resman_.LoadResource(Mesh, "TowerMesh", filename.c_str());
	ProgressLoading(1);

	FinishLoading();
}


void Game::SetupScene(void){

    // Set background color for the scene
    scene_.SetBackgroundColor(viewport_background_color_g);
	//CreateAsteroidField();

	// helicopter base
	game::Helicopter *chopperbase = CreateHelicopter("HelicopterBase", "CylinderMesh", "3TTexturedMaterial", "Stars", "SkyLightTex");
    // Adjust the instance
	chopperbase->Translate(glm::vec3(1.4, 2.0, 0.0));
	chopperbase->Rotate(glm::angleAxis(-glm::pi<float>() / 180.0f * 90.0f, glm::vec3(1.0, 0.0, 0.0)));
    chopperbase->Scale(glm::vec3(0.5, 0.7, 0.5));
	player_ = chopperbase;

	// Helicopter parts
	// rotating base
	game::SceneNode *rotorbase = CreateInstance("CylinderInstance2", "CylinderMesh", "3TTexturedMaterial", "Stars", "SkyLightTex");
	// Adjust the instance
	rotorbase->Scale(glm::vec3(0.2, 0.1, 0.2));
	rotorbase->Translate(glm::vec3(0.0, 0.0, 0.25));
	rotorbase->Rotate(glm::angleAxis(glm::pi<float>() / 180.0f * 90.0f, glm::vec3(1.0, 0.0, 0.0)));

	// first part of rotor
	game::SceneNode *rotorfront = CreateInstance("CylinderInstance3", "CylinderMesh", "3TTexturedMaterial", "Stripes", "SkyLightTex");
	// Adjust the instance
	rotorfront->Scale(glm::vec3(0.1, 2.0, 0.01));
	rotorfront->Translate(glm::vec3(0.0, 0.025, 0.0));
	rotorfront->Rotate(glm::angleAxis(-glm::pi<float>() / 180.0f * 90.0f, glm::vec3(1.0, 0.0, 0.0)));

	// second part of rotor
	game::SceneNode *rotorside = CreateInstance("CylinderInstance4", "CylinderMesh", "3TTexturedMaterial", "Stripes", "SkyLightTex");
	// Adjust the instance
	rotorside->Scale(glm::vec3(0.01, 2.0, 0.1));
	rotorside->Translate(glm::vec3(0.0, 0.025, 0.0));
	rotorside->Rotate(glm::angleAxis(-glm::pi<float>() / 180.0f * 90.0f, glm::vec3(0.0, 0.0, 1.0)));
	player_->AddNode(rotorbase);
	rotorbase->AddNode(rotorfront);
	rotorbase->AddNode(rotorside);


	// End helicopter parts
	/*
	for (int i = 0; i < 1; i++) {
		std::string name = std::string(std::string("Enemy") + std::to_string(i+1));
		game::Enemies *e = new Enemies(name, resman_.GetResource("CylinderMesh"), resman_.GetResource("3TTexturedMaterial"), resman_.GetResource("Crumpled"), i+1);
		scene_.AddNode(e);
		e->SetPosition(glm::vec3(25.0, 0.5, i+1));
		e->SetTarget(player_);
		enemy_ = e;
		enemyList.push_back(e);
	}
	*/

	game::Projectile *p = new Projectile("Projectile", resman_.GetResource("CylinderMesh"), resman_.GetResource("ShinyBlueMetal"), resman_.GetResource("Crumpled"),player_);
	scene_.AddNode(p);
	p->SetPosition(glm::vec3(0.0,0.0,0.0));
	p->SetScale(glm::vec3(0.08, 0.3, 0.08));
	p->Rotate(glm::angleAxis(-glm::pi<float>() / 180.0f * 90.0f, glm::vec3(1.0, 0.0, 0.0)));
	p->SetVisibility(false);
	bullet_ = p;
	projectileList.push_back(p);

	// Ground Plane
	game::SceneNode *plane = CreateInstance("PlaneInstance1", "PlaneMesh", "3TTexturedMaterial", "Checker");
	// Adjust the instance
	plane->Scale(glm::vec3(500.0, 500.0, 500.0));
	plane->Rotate(glm::angleAxis(glm::pi<float>() / 180.0f * 90.0f, glm::vec3(1.0, 0.0, 0.0)));

	// GUI ELEMENTS
	game::SceneNode *GUIElement = new SceneNode("GUIContinue", resman_.GetResource("PlaneMesh"), resman_.GetResource("TexturedMaterial"), resman_.GetResource("GUIContinue"));
	GUIElement->Scale(glm::vec3(0.24, 0.02, 0.000001));
	GUIElement->Translate(glm::vec3(0.0, 0.0, -0.1));
	//GUIElement->Rotate(glm::angleAxis(glm::pi<float>() / 180.0f * 180.0f, glm::vec3(0.0, 1.0, 0.0)));
	GUIElement->Rotate(glm::angleAxis(glm::pi<float>() / 180.0f * 180.0f, glm::vec3(0.0, 0.0, 1.0)));
	GUIElement->EnableBlending(1);
	GUISpace_.push_back(GUIElement);

	GUIElement = new SceneNode("GUICockpit", resman_.GetResource("PlaneMesh"), resman_.GetResource("TexturedMaterial"), resman_.GetResource("GUICockpit"));
	GUIElement->Scale(glm::vec3(0.9, 0.60, 0.000001));
	GUIElement->Translate(glm::vec3(0.0105, -0.051, 0.0));
	//GUIElement->Rotate(glm::angleAxis(glm::pi<float>() / 180.0f * 180.0f, glm::vec3(0.0, 1.0, 0.0)));
	GUIElement->Rotate(glm::angleAxis(glm::pi<float>() / 180.0f * 180.0f, glm::vec3(0.0, 0.0, 1.0)));
	GUIElement->EnableBlending(1);
	GUISpace_.push_back(GUIElement);

	// Create skybox
	SceneNode *skybox_ = CreateInstance("SkyBox1", "CubeMesh", "SkyboxMaterial");
	skybox_->Scale(glm::vec3(5.0, 5.0, 5.0));
}


void Game::MainLoop(void){
	static double last_time = 0;
	static double bullet_last = 0;
	static double rocket_last = 0;
	static double missile_last = 0;
	double current_time = glfwGetTime();
	double bullet_time = glfwGetTime();
	double rocket_time = glfwGetTime();
	double missile_time = glfwGetTime();

    // Loop while the user did not close the window
    while (!glfwWindowShouldClose(window_)){

        // Animate the scene
        if (animating_){
			current_time = glfwGetTime();
			bullet_time = current_time;
			rocket_time = current_time;
			missile_time = current_time;

			//std::cout << "Player HP: " << player_->getHealth() << "   Enemies Left: " << enemyList.size() << std::endl;
			if ((current_time - last_time) > 0.01) {
				scene_.Update();
				last_time = current_time;
				// Animate the cube

				// Animate the turret
				glm::vec3 forwards = glm::vec3(player_->GetUp().x, 0, player_->GetUp().z);
				glm::vec3 sides = glm::vec3(player_->GetSide().x, 0, player_->GetSide().z);
				forwards = glm::normalize(forwards);
				sides = glm::normalize(sides);
				if (keys.at("w")) {
					player_->ApplyAngForce(glm::vec3(-0.01, 0, 0));
					player_->ApplyForce(forwards*0.001f);
				}
				else
					if (keys.at("s")) {
						player_->ApplyAngForce(glm::vec3(0.01, 0, 0));
						player_->ApplyForce(forwards*-0.001f);
					}
				if (keys.at("a")) {
					player_->ApplyAngForce(glm::vec3(0, 0, -0.001));
				}
				else
					if (keys.at("d")) {
						player_->ApplyAngForce(glm::vec3(0, 0, 0.001));
					}
				if (keys.at("left")) {
					player_->ApplyAngForce(glm::vec3(0, -0.01, 0));
					player_->ApplyForce(sides*-0.001f);
				}
				else
					if (keys.at("right")) {
						player_->ApplyAngForce(glm::vec3(0, 0.01, 0));
						player_->ApplyForce(sides*0.001f);
					}
				if (keys.at(" ")) {
					player_->ApplyForce(player_->GetForward()*(-0.001f));
				}
				else
					if (keys.at("lshift")) {
						player_->ApplyForce(player_->GetForward()*(0.001f));
					}
				SceneNode *node = scene_.GetNode("HelicopterBase");
				//camera_.SetPosition(node->GetPosition() - node->GetUp()*5.0f - node->GetForward()*1.0f); //
				if (thirdperson_) {
					camera_.SetPosition(player_->GetPosition() - forwards * 5.0f + glm::vec3(0.0, 1.0, 0.0)); //
					camera_.SetView(camera_.GetPosition(), node->GetPosition(), glm::vec3(0.0, 1.0, 0.0));
				}
				else {
					glm::vec3 temppos = player_->GetPosition();
					glm::vec3 temp = player_->GetUp();
					float speed = glm::length(player_->GetVelocity());
					temp *= 2;
					temppos += temp;
					camera_.SetView(temppos, temppos + temp, -player_->GetForward());
					GUISpace_[1]->Translate(glm::vec3(0.0, 0.001*speed, 0.0));
				}
				
				node = scene_.GetNode("SkyBox1");
				node->SetPosition(camera_.GetPosition());

				node = scene_.GetNode("CylinderInstance2");
				glm::quat rotation = glm::angleAxis(glm::pi<float>() / 180.0f * (10.0f + glm::length(player_->GetVelocity()) * 100.0f), glm::vec3(0.0, 1.0, 0.0));
				node->Rotate(rotation);

				//node = scene_.GetNode("Enemy1");
				//PROJECTILES
				//Shooting the projectile. Press 'Up' to shoot



				if (keys.at("up") && (bullet_time - bullet_last) >= 0.125) {
					Shoot(player_, glm::vec3(player_->GetUp().x * 5.0, player_->GetUp().y*5.0, player_->GetUp().z * 5.0));
					bullet_last = bullet_time;
				}
				if (keys.at("down") && (rocket_time - rocket_last) >= 0.9) {
					ShootRocket(player_, glm::vec3(player_->GetUp().x * 4.0, player_->GetUp().y*4.0, player_->GetUp().z * 4.0));
					rocket_last = rocket_time;
				}

				if (keys.at("lctrl") && (missile_time - missile_last) >= 5.0) {
					ShootMissile(player_, glm::vec3(player_->GetUp().x * 4.0, player_->GetUp().y*4.0, player_->GetUp().z * 4.0));
					missile_last = missile_time;
				}
				//--------------------------------------
	

				for (int i = 0; i < projectileList.size(); i++) {
					Projectile *bullet = projectileList[i];
					//Only fire when the bullet isnt in the middle of traveling
					if (projectileList[i]->getDuration() >= 400) {
						bullet->SetVisibility(false);
						if (bullet->GetType() >= 1) {
							CreateExplosion(bullet->GetPosition(), "BulletExplosion", "SphereParticles", "ParticleMaterial");
						}
						std::vector<SceneNode*> *children = bullet->GetChildren();
						for (int i = 0; i < children->size(); i++) {
							(*(bullet->GetChildren()))[i]->SetVisibility(false);
						}
						projectileList.erase(projectileList.begin() + i);
						i--;
						break;
					}
					//----------------------------
					Enemies* closest = NULL;
					for (int j = 0; j < enemyList.size(); j++) {
						Enemies *enemy = enemyList[j];
						if (bullet->GetType() == 2) {
							if (glm::distance(enemy->GetPosition(), bullet->GetPosition()) < 5) {
								bullet->SetTarget(enemy);
							}
						}
						
						//COLLISION DETECTIONS
						//bullet vs enemy
						if (RayCollide(bullet, enemy) && bullet->getShooter() == player_) {
							if (!closest) {
								closest = enemy;
							}
							else if (glm::distance(bullet->GetPosition(), enemy->GetPosition()) < glm::distance(bullet->GetPosition(), closest->GetPosition())) {
								closest = enemy;
							}
						}
					}
					if (closest) {
						closest->setEnemyHit(true);
						if (bullet->GetName().compare("Rocket") == 0) {
							closest->setHealth(closest->getHealth() - 300);
						}
						else if(bullet->GetName().compare("Missile") == 0){
							closest->setHealth(closest->getHealth() - 1000);
						}
						else {
							closest->setHealth(closest->getHealth() - 50);
						}
						bullet->SetVisibility(false);
						if (bullet->GetType() >= 1) {
							CreateExplosion(bullet->GetPosition(), "BulletExplosion", "SphereParticles", "ParticleMaterial");
						}
						std::vector<SceneNode*> *children = bullet->GetChildren();
						for (int i = 0; i < children->size(); i++) {
							(*(bullet->GetChildren()))[i]->SetVisibility(false);
						}
						projectileList.erase(projectileList.begin() + i);
						i--;
					} else

					if (bullet->GetPosition().y < 0.01) {
						bullet->SetVisibility(false);
						if (bullet->GetType() >= 1) {
							CreateExplosion(bullet->GetPosition(), "BulletExplosion", "SphereParticles", "ParticleMaterial");
						}
						std::vector<SceneNode*> *children = bullet->GetChildren();
						for (int i = 0; i < children->size(); i++) {
							(*(bullet->GetChildren()))[i]->SetVisibility(false);
						}
						projectileList.erase(projectileList.begin() + i);
						i--;
					} else

					//Player vs Projectiles
					if (RayCollide(bullet, player_) && bullet->getShooter() != player_) {
						player_->setHealth(player_->getHealth() - 20);
						bullet->SetVisibility(false);
						if (bullet->GetType() >= 1) {
							CreateExplosion(bullet->GetPosition(), "BulletExplosion", "SphereParticles", "ParticleMaterial");
						}
						std::vector<SceneNode*> *children = bullet->GetChildren();
						for (int i = 0; i < children->size(); i++) {
							(*(bullet->GetChildren()))[i]->SetVisibility(false);
						}
						projectileList.erase(projectileList.begin() + i);
						i--;
					}
					if (player_->getHealth() <= 0) {
						
					}
				}
				//--------------------------------------------------------------
				//
				// ENEMIES
				for (int i = 0; i < enemyList.size(); i++) {
					Enemies* enemy = enemyList[i];
					if (enemy->getHealth() <= 0) {
						CreateExplosion(enemy->GetPosition(), "EnemyExplosion", "SphereParticles", "ParticleMaterial");
						enemyList.erase(enemyList.begin() + i);
						break;
					}
					//-----------------------------------
						//Enemy Shooting
					if (enemy->getState() == 1 && enemy->GetCanfire()) {
						Shoot(enemy, glm::normalize(enemy->GetTarget()->GetPosition() - enemy->GetPosition()));
						enemy->ResetFire();
					}
					//-----------------------------------

					// Enemy Collide on enemy
					for (int j = 0; j < enemyList.size(); j++) {
						Enemies* enemyT = enemyList[j];
						if (i != j && enemyT->GetType() < 4 && enemy->GetType() < 4) {
							if (Collide(enemyT, enemy)) {
								std::cout << "hit" << std::endl;
								glm::vec3 deltaPos = enemyT->GetPosition() - enemy->GetPosition();
								glm::vec3 normalPos = glm::normalize(deltaPos);
								glm::vec3 P1 = enemy->GetPosition();
								glm::vec3 P2 = enemyT->GetPosition();
								float R1 = enemy->GetScale().x / 2.0f;
								float R2 = enemyT->GetScale().x / 2.0f;
								glm::vec3 collisionPoint = (P1 * R2 + P2 * R1) / (R1 + R2);
								float dist = glm::distance(P1, P2);

								glm::vec3 Push1 = collisionPoint + R1 * (P1 - P2) / dist;
								glm::vec3 Push2 = collisionPoint + R2 * (P2 - P1) / dist;

								enemy->SetPosition(Push1);
								enemyT->SetPosition(Push2);
								enemy->SetVelocity(glm::reflect(enemy->GetVelocity(), normalPos)*0.9f);
								enemyT->SetVelocity(glm::reflect(enemyT->GetVelocity(), normalPos)*0.9f);
							}
						}
					}
					// Enemy collide with player
					if (Collide(player_, enemy)) {
						std::cout << "hit" << std::endl;
						glm::vec3 deltaPos = player_->GetPosition() - enemy->GetPosition();
						glm::vec3 normalPos = glm::normalize(deltaPos);
						glm::vec3 P1 = enemy->GetPosition();
						glm::vec3 P2 = player_->GetPosition();
						float R1 = enemy->GetScale().x / 2.0f;
						float R2 = player_->GetScale().x / 2.0f;
						glm::vec3 collisionPoint = (P1 * R2 + P2 * R1) / (R1 + R2);
						float dist = glm::distance(P1, P2);

						glm::vec3 Push1 = collisionPoint + R1 * (P1 - P2) / dist;
						glm::vec3 Push2 = collisionPoint + R2 * (P2 - P1) / dist;

						enemy->SetPosition(Push1);
						player_->SetPosition(Push2);
						enemy->SetVelocity(glm::reflect(enemy->GetVelocity(), normalPos)*0.9f);
						player_->SetVelocity(glm::reflect(player_->GetVelocity(), normalPos)*0.9f);
					}
				}
			
				//--------------------------------------------------------------
				//Waves
				GUISpace_[0]->SetVisibility(false);
				if (enemyList.size()<=0) {
					GUISpace_[0]->SetVisibility(true);
					if (keys.at("F4")) {
						wave = wave + 2;
						for (int i = 0; i < wave+3; i++) {
							std::string name = std::string(std::string("Enemy") + std::to_string(i + 1));
							int type = rand() % 4 + 1;
							const Resource *texture;
							const Resource *mesh = resman_.GetResource("CylinderMesh");
							game::Enemies *e;
							if (type == 1) {
								texture = resman_.GetResource("Bluecamo");
								mesh = resman_.GetResource("CylinderMesh");
								e = new Enemies(name, mesh, resman_.GetResource("3TTexturedMaterial"), texture, type);
								//e->SetScale(glm::vec3(0.1, 0.2, 0.1));
							}
							else if (type == 2) {
								texture = resman_.GetResource("Greycamo");
								e = new Enemies(name, mesh, resman_.GetResource("3TTexturedMaterial"), texture, type);
								//e->SetScale(glm::vec3(0.7, 0.7, 1.0));
							}
							else if (type == 3) {
								texture = resman_.GetResource("GreenEl");
								e = new Enemies(name, mesh, resman_.GetResource("3TTexturedMaterial"), texture, type);
								//e->SetScale(glm::vec3(0.9, 0.9, 1.1));
							}
							else {
								mesh = resman_.GetResource("TowerMesh");
								texture = resman_.GetResource("TowerTexture");
								e = new Enemies(name, mesh, resman_.GetResource("3TTexturedMaterial"), texture, type);
								e->SetScale(glm::vec3(5, 5, 5));
							}
							scene_.AddNode(e);
							e->SetPosition(glm::vec3((float)rand() / RAND_MAX * 250.0 - 125.0, 0.5, (float)rand() / RAND_MAX * 250.0 - 125.0));
							e->SetTarget(player_);
							enemy_ = e;
							enemyList.push_back(e);
						}
						player_->setHealth(player_->getHealth() + 100);
					}
				}
				// GUI stuff
				GUISpace_[1]->SetVisibility(!thirdperson_);

            }
        }



		/*if (materialToggle) {
			
		}
		else {
			
		}*/

        // Draw the scene
        //scene_.Draw(&camera_);
		glClearColor(0.0, 0.0, 0.0, 0.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		scene_.DrawToTexture(&camera_);
		scene_.DisplayTexture(resman_.GetResource("ScreenSpaceMaterial")->GetResource());

		// Draw GUI elements
		// Clear background
		
		for (int i = 0; i < GUISpace_.size(); i++) {
			GUISpace_[i]->Draw(&GUIcamera_);
		}


        // Push buffer drawn in the background onto the display
        glfwSwapBuffers(window_);

        // Update other events like input handling
        glfwPollEvents();
    }


}

int Game::changeEnemyState(Enemies *e, Helicopter *p) {
	return 0;
}

//For shooting projectiles
void Game::Shoot(SceneNode *s, glm::vec3 v) {
	//std::cout << "SHOOT" << std::endl;
	game::Projectile *p = new Projectile("Projectile", resman_.GetResource("CylinderMesh"), resman_.GetResource("ShinyBlueMetal"), resman_.GetResource("Crumpled"), s);
	scene_.AddNode(p);

	p->SetPosition(s->GetPosition());

	p->SetScale(glm::vec3(0.04, 0.4, 0.04));
	glm::vec3 velocity = glm::vec3(v.x/3, (v.y) /3,v.z/3);
	p->SetVelocity(velocity);
	p->SetVisibility(true);
	p->setShoot(true);
	p->SetOrientation(s->GetOrientation());
	p->setDuration(0);
	projectileList.push_back(p);
}
void Game::ShootRocket(SceneNode *s, glm::vec3 v) {
	//std::cout << "SHOOT" << std::endl;
	game::Projectile *p = new Projectile("Rocket", resman_.GetResource("CylinderMesh"), resman_.GetResource("ShinyBlueMetal"), resman_.GetResource("Crumpled"), s);
	game::SceneNode *particles = new SceneNode("RocketParticle", resman_.GetResource("ConeParticles"), resman_.GetResource("FireMaterial"), resman_.GetResource("Flame"));
	p->AddNode(particles);
	scene_.AddNode(p);
	scene_.AddNode(particles);

	glm::quat rotation = glm::angleAxis(-glm::pi<float>() / 180.0f * 180.0f, glm::vec3(0.0, 0.0, 1.0));
	particles->Rotate(rotation);
	particles->EnableBlending(2);
	particles->SetScale(glm::vec3(0.2, 1.0, 0.2));
	particles->SetColor(glm::vec3(0.08, 0.005, 0.04));

	p->SetPosition(s->GetPosition());

	p->SetScale(glm::vec3(0.08, 0.6, 0.08));
	glm::vec3 velocity = glm::vec3(v.x / 7, (v.y) / 7, v.z / 7);
	p->SetVelocity(velocity);
	p->SetVisibility(true);
	p->setShoot(true);
	p->SetOrientation(s->GetOrientation());
	p->setDuration(0);
	p->SetType(1);
	projectileList.push_back(p);
}

void Game::ShootMissile(SceneNode *s, glm::vec3 v) {
	//std::cout << "SHOOT" << std::endl;
	game::Projectile *p = new Projectile("Missile", resman_.GetResource("CylinderMesh"), resman_.GetResource("ShinyBlueMetal"), resman_.GetResource("Crumpled"), s);
	game::SceneNode *particles = new SceneNode("MissileParticle", resman_.GetResource("TorusParticles"), resman_.GetResource("FireMaterial"), resman_.GetResource("Flame"));
	p->AddNode(particles);
	scene_.AddNode(p);
	scene_.AddNode(particles);

	glm::quat rotation = glm::angleAxis(-glm::pi<float>() / 180.0f * 90.0f, glm::vec3(1.0, 0.0, 0.0));
	particles->Rotate(rotation);
	particles->EnableBlending(2);
	particles->SetScale(glm::vec3(0.2, 0.2, 1.0));
	particles->SetColor(glm::vec3(0.005,0.01,0.05));
	particles->Translate(glm::vec3(0.0, -0.2, 0.0));

	p->SetPosition(s->GetPosition());

	p->SetScale(glm::vec3(0.12, 0.7, 0.12));
	glm::vec3 velocity = glm::vec3(v.x / 7, (v.y) / 7, v.z / 7);
	p->SetVelocity(velocity);
	p->SetVisibility(true);
	p->setShoot(true);
	p->SetOrientation(s->GetOrientation());
	p->setDuration(0);
	p->SetType(2);
	projectileList.push_back(p);
}



//Use this for all collisions between objects that are scene nodes
bool Game::Collide(SceneNode *o1, SceneNode *o2) {
	//Check distance of 2 objects
	if(glm::distance(o1->GetPosition(), o2->GetPosition()) < o1->GetScale().x/2.0f + o2->GetScale().x/2.0f && o1->GetVisibility() == true && o2->GetVisibility() == true){
		//std::cout << "HIT" << std::endl;
		return true;
	}
	else {
		return false;
	}
}

bool Game::RayCollide(SceneNode *rayOrg, SceneNode *rayTarg) {
	//Check distance of 2 objects
	float distance = 0.1;
	bool hit = glm::intersectRaySphere(rayOrg->GetPosition(), rayOrg->GetUp(), rayTarg->GetPosition(), glm::length(rayTarg->GetScale()) / 2.0f, distance);
	if (distance < glm::length(rayOrg->GetVelocity()) && hit && rayOrg->GetVisibility() == true && rayTarg->GetVisibility() == true) {
		//std::cout << "HIT" << std::endl;
		return true;
	}
	else {
		return false;
	}
}

void Game::KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods){

    // Get user data with a pointer to the game class
    void* ptr = glfwGetWindowUserPointer(window);
    Game *game = (Game *) ptr;

    // Quit game if 'q' is pressed
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS){
        glfwSetWindowShouldClose(window, true);
    }

    // Stop animation if space bar is pressed
    /*if (key == GLFW_KEY_SPACE && action == GLFW_PRESS){
        game->animating_ = (game->animating_ == true) ? false : true;
    }*/

    // View control
    float rot_factor(glm::pi<float>() / 180);
    float trans_factor = 1.0;
	if (action == GLFW_PRESS) {
		if (key == GLFW_KEY_UP) {
			//game->camera_.Pitch(rot_factor);
			game->keys.at("up") = true;
		}
		if (key == GLFW_KEY_DOWN) {
			//game->camera_.Pitch(-rot_factor);
			game->keys.at("down") = true;
		}
		if (key == GLFW_KEY_LEFT) {
			game->keys.at("left") = true;
		}
		if (key == GLFW_KEY_RIGHT) {
			game->keys.at("right") = true;
		}
		if (key == GLFW_KEY_W) {
			game->keys.at("w") = true;
		}
		if (key == GLFW_KEY_A) {
			game->keys.at("a") = true;
		}
		if (key == GLFW_KEY_S) {
			game->keys.at("s") = true;
		}
		if (key == GLFW_KEY_D) {
			game->keys.at("d") = true;
		}
		if (key == GLFW_KEY_X) {
			game->camera_.Roll(rot_factor);
		}
		if (key == GLFW_KEY_Z) {
			game->camera_.Roll(-rot_factor);
		}
		if (key == GLFW_KEY_SPACE) {
			game->keys.at(" ") = true;
		}
		if (key == GLFW_KEY_LEFT_SHIFT) {
			game->keys.at("lshift") = true;
		}
		if (key == GLFW_KEY_LEFT_CONTROL) {
			game->keys.at("lctrl") = true;
		}
		if (key == GLFW_KEY_V) {
			game->ChangePerspective();
		}
		if (key == GLFW_KEY_F4) {
			game->keys.at("F4") = true;
		}
	}
	else if (action == GLFW_RELEASE) {
		if (key == GLFW_KEY_W) {
			game->keys.at("w") = false;
		}
		if (key == GLFW_KEY_A) {
			game->keys.at("a") = false;
		}
		if (key == GLFW_KEY_S) {
			game->keys.at("s") = false;
		}
		if (key == GLFW_KEY_D) {
			game->keys.at("d") = false;
		}
		if (key == GLFW_KEY_SPACE) {
			game->keys.at(" ") = false;
		}
		if (key == GLFW_KEY_LEFT_SHIFT) {
			game->keys.at("lshift") = false;
		}
		if (key == GLFW_KEY_LEFT_CONTROL) {
			game->keys.at("lctrl") = false;
		}
		if (key == GLFW_KEY_LEFT) {
			game->keys.at("left") = false;
		}
		if (key == GLFW_KEY_RIGHT) {
			game->keys.at("right") = false;
		}
		if (key == GLFW_KEY_V) {
			
		}
		if (key == GLFW_KEY_F4) {
			game->keys.at("F4") = false;
		}
		if (key == GLFW_KEY_UP) {
			//game->camera_.Pitch(rot_factor);
			game->keys.at("up") = false;
		}
		if (key == GLFW_KEY_DOWN) {
			//game->camera_.Pitch(-rot_factor);
			game->keys.at("down") = false;
		}
	}
	if (key == GLFW_KEY_R && action == GLFW_PRESS) {
		if (game->materialToggle) {
			game->materialToggle = false;
		}
		else {
			game->materialToggle = true;
		}
	}
}

void Game::ChangePerspective() {
	thirdperson_ = !thirdperson_;
	int width, height;
	glfwGetFramebufferSize(window_, &width, &height);
	if (thirdperson_) {
		camera_.SetProjection(camera_fov_g, camera_near_clip_distance_g, camera_far_clip_distance_g, width, height);
	}
	else {
		camera_.SetProjection(camera_fov_g*1.6, camera_near_clip_distance_g, camera_far_clip_distance_g, width, height);
	}
}


void Game::ResizeCallback(GLFWwindow* window, int width, int height){

    // Set up viewport and camera projection based on new window size
    glViewport(0, 0, width, height);
    void* ptr = glfwGetWindowUserPointer(window);
    Game *game = (Game *) ptr;
    game->camera_.SetProjection(camera_fov_g, camera_near_clip_distance_g, camera_far_clip_distance_g, width, height);
	game->GUIcamera_.SetProjection(camera_fov_g, camera_near_clip_distance_g, camera_far_clip_distance_g, width, height);
}


Game::~Game(){
    
    glfwTerminate();
}


Asteroid *Game::CreateAsteroidInstance(std::string entity_name, std::string object_name, std::string material_name, std::string texture_name){

    // Get resources
    Resource *geom = resman_.GetResource(object_name);
    if (!geom){
        throw(GameException(std::string("Could not find resource \"")+object_name+std::string("\"")));
    }

    Resource *mat = resman_.GetResource(material_name);
    if (!mat){
        throw(GameException(std::string("Could not find resource \"")+material_name+std::string("\"")));
    }

	Resource *tex = NULL;
	if (texture_name != "") {
		tex = resman_.GetResource(texture_name);
		if (!mat) {
			throw(GameException(std::string("Could not find resource \"") + material_name + std::string("\"")));
		}
	}

    // Create asteroid instance
    Asteroid *ast = new Asteroid(entity_name, geom, mat, tex);
    scene_.AddNode(ast);
    return ast;
}


void Game::CreateAsteroidField(int num_asteroids){

    // Create a number of asteroid instances
    for (int i = 0; i < num_asteroids; i++){
        // Create instance name
        std::stringstream ss;
        ss << i;
        std::string index = ss.str();
        std::string name = "AsteroidInstance" + index;

        // Create asteroid instance
        Asteroid *ast = CreateAsteroidInstance(name, "SimpleSphereMesh", "ShinyBlueMaterial", "Checker");

        // Set attributes of asteroid: random position, orientation, and
        // angular momentum
        ast->SetPosition(glm::vec3(-300.0 + 600.0*((float) rand() / RAND_MAX), -300.0 + 600.0*((float) rand() / RAND_MAX), 600.0*((float) rand() / RAND_MAX)));
        ast->SetOrientation(glm::normalize(glm::angleAxis(glm::pi<float>()*((float) rand() / RAND_MAX), glm::vec3(((float) rand() / RAND_MAX), ((float) rand() / RAND_MAX), ((float) rand() / RAND_MAX)))));
        ast->SetAngM(glm::normalize(glm::angleAxis(0.05f*glm::pi<float>()*((float) rand() / RAND_MAX), glm::vec3(((float) rand() / RAND_MAX), ((float) rand() / RAND_MAX), ((float) rand() / RAND_MAX)))));
    }
}


SceneNode *Game::CreateInstance(std::string entity_name, std::string object_name, std::string material_name, std::string texture_name, std::string envmap_name) {

	Resource *geom = resman_.GetResource(object_name);
	if (!geom) {
		throw(GameException(std::string("Could not find resource \"") + object_name + std::string("\"")));
	}

	Resource *mat = resman_.GetResource(material_name);
	if (!mat) {
		throw(GameException(std::string("Could not find resource \"") + material_name + std::string("\"")));
	}

	Resource *tex = NULL;
	if (texture_name != "") {
		tex = resman_.GetResource(texture_name);
		if (!tex) {
			throw(GameException(std::string("Could not find resource \"") + material_name + std::string("\"")));
		}
	}

	Resource *envmap = NULL;
	if (envmap_name != "") {
		envmap = resman_.GetResource(envmap_name);
		if (!envmap) {
			throw(GameException(std::string("Could not find resource \"") + envmap_name + std::string("\"")));
		}
	}

	SceneNode *scn = scene_.CreateNode(entity_name, geom, mat, tex, envmap);
	return scn;
}

SceneNode *Game::CreateExplosion(glm::vec3 position, std::string entity_name, std::string object_name, std::string material_name, std::string texture_name, std::string envmap_name) {
	Resource *geom = resman_.GetResource(object_name);
	if (!geom) {
		throw(GameException(std::string("Could not find resource \"") + object_name + std::string("\"")));
	}

	Resource *mat = resman_.GetResource(material_name);
	if (!mat) {
		throw(GameException(std::string("Could not find resource \"") + material_name + std::string("\"")));
	}

	Resource *tex = NULL;
	if (texture_name != "") {
		tex = resman_.GetResource(texture_name);
		if (!tex) {
			throw(GameException(std::string("Could not find resource \"") + material_name + std::string("\"")));
		}
	}

	Resource *envmap = NULL;
	if (envmap_name != "") {
		envmap = resman_.GetResource(envmap_name);
		if (!envmap) {
			throw(GameException(std::string("Could not find resource \"") + envmap_name + std::string("\"")));
		}
	}
	game::SceneNode *particles = scene_.CreateNode(entity_name, geom, mat, tex, envmap);
	particles->SetPosition(position);
	particles->SetLifespan(((float)rand() / RAND_MAX) * 5.0 + 1.0);
	particles->SetCurLife(glfwGetTime());
	particles->SetOffset(-fmod(glfwGetTime(), particles->GetLifespan()));
	particles->SetColor(glm::vec3(((float)rand() / RAND_MAX), ((float)rand() / RAND_MAX), ((float)rand() / RAND_MAX)));
	particles->EnableBlending(2);

	return particles;
}

Helicopter *Game::CreateHelicopter(std::string entity_name, std::string object_name, std::string material_name, std::string texture_name, std::string envmap_name) {

	Resource *geom = resman_.GetResource(object_name);
	if (!geom) {
		throw(GameException(std::string("Could not find resource \"") + object_name + std::string("\"")));
	}

	Resource *mat = resman_.GetResource(material_name);
	if (!mat) {
		throw(GameException(std::string("Could not find resource \"") + material_name + std::string("\"")));
	}

	Resource *tex = NULL;
	if (texture_name != "") {
		tex = resman_.GetResource(texture_name);
		if (!tex) {
			throw(GameException(std::string("Could not find resource \"") + material_name + std::string("\"")));
		}
	}

	Resource *envmap = NULL;
	if (envmap_name != "") {
		envmap = resman_.GetResource(envmap_name);
		if (!envmap) {
			throw(GameException(std::string("Could not find resource \"") + envmap_name + std::string("\"")));
		}
	}

	Helicopter *scn = new Helicopter(entity_name, geom, mat, tex, envmap);
	scene_.AddNode(scn);
	return scn;
}

void Game::SetupLoading(int maxtime) {
	// Load material to be applied to objects without lighting
	std::string filename = std::string(MATERIAL_DIRECTORY) + std::string("/textured_material");
	resman_.LoadResource(Material, "TexturedMaterial", filename.c_str());
	// Load front of loading bar
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/loadingbarback.png");
	resman_.LoadResource(Texture, "LoadingBack", filename.c_str());
	// Load back of loading bar
	filename = std::string(MATERIAL_DIRECTORY) + std::string("/textures/loadingbarfront.png");
	resman_.LoadResource(Texture, "LoadingFront", filename.c_str());
	// Mesh for loading bar
	resman_.CreatePlane("PlaneMesh", glm::vec3(1.0, 1.0, 1.0));

	maxStepsToLoad = maxtime;
	currentLoadSteps = 0;

	LoadingFront = new SceneNode("LoadingFront", resman_.GetResource("PlaneMesh"), resman_.GetResource("TexturedMaterial"), resman_.GetResource("LoadingFront"));
	LoadingFront->SetScale(glm::vec3(0.5 * 0.0, 0.5, 0.5));
	LoadingFront->Rotate(glm::angleAxis(glm::pi<float>() / 180.0f * 180.0f, glm::vec3(0.0, 0.0, 1.0)));
	LoadingBack = new SceneNode("LoadingBack", resman_.GetResource("PlaneMesh"), resman_.GetResource("TexturedMaterial"), resman_.GetResource("LoadingBack"));
	LoadingBack->SetScale(glm::vec3(0.5 * 0.0, 0.5, 0.5));
}

void Game::ProgressLoading(int time) {
	currentLoadSteps += time;
	if (!glfwWindowShouldClose(window_)) {
		glClearColor(viewport_background_color_g[0],
			viewport_background_color_g[1],
			viewport_background_color_g[2], 0.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glClearColor(0.0, 0.0, 0.0, 0.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		LoadingFront->SetScale(glm::vec3(0.5 * (currentLoadSteps / maxStepsToLoad), 0.5, 0.5));
		LoadingFront->SetPosition(glm::vec3(-0.25 * (currentLoadSteps / maxStepsToLoad) + 0.25, 0.0, 0.0));
		LoadingBack->SetScale(glm::vec3(0.5, 0.5, 1.0));
		LoadingBack->Draw(&GUIcamera_);
		LoadingFront->Draw(&GUIcamera_);
		// Push buffer drawn in the background onto the display
		glfwSwapBuffers(window_);

		// Update other events like input handling
		glfwPollEvents();
	}
}

void Game::FinishLoading() {
	LoadingBack->SetVisibility(false);
	LoadingFront->SetVisibility(false);
}

} // namespace game
