#include "enemies.h"

namespace game {

Enemies::Enemies(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture, int s) : SceneNode(name, geometry, material, texture) {
	health = 1000;
	state = 1;
	//velocity = glm::vec3(0.0,0.0,0.0);
}


Enemies::~Enemies(){
}

glm::quat Enemies::GetAngM(void) const {

    return angm_;
}


void Enemies::SetAngM(glm::quat angm){

    angm_ = angm;
}
//Health
float Enemies::getHealth() {
	return health;
}

void Enemies::setHealth(float x) {
	health = x;
}

//Was hit flag
bool Enemies::enemyHit() {
	return wasHit;
}
void Enemies::setEnemyHit(bool r) {
	wasHit = r;
}


void Enemies::Update(){
		//std::cout << GetPosition().x << ", " << GetPosition().z << std::endl;
		std::cout << "Enemy Health: " << health << std::endl;
		position_.x += velocity_.x;
		position_.z += velocity_.z;


		Rotate(angm_);
}



} // namespace game

