Press 'R' to change the lighting 


Resources:

	Crumpled:
	https://freestocktextures.com/texture/shiny-silver-metallic-paper,1038.html