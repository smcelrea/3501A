#ifndef ENEMIES_H_
#define ENEMIES_H_

#include <string>
#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#define GLM_FORCE_RADIANS
#include <glm/gtc/quaternion.hpp>

#include "resource.h"
#include "scene_node.h"
#include "helicopter.h"

namespace game {

    // Abstraction of an enemies
    class Enemies : public SceneNode {

        public:
            // Create enemies from given resources
            Enemies(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture,int s);
            // Destructor
            ~Enemies();
			//
			float getHealth();
			void setHealth(float x);
			//  
            // Get/set attributes specific to enemiess
            glm::quat GetAngM(void) const;
            void SetAngM(glm::quat angm);
            // Update geometry configuration
            void Update();

			bool enemyHit();
			void setEnemyHit(bool r);
			
            
        private:
            // Angular momentum of enemies
            glm::quat angm_;
			//
			//glm::vec3 velocity;
			//
			float health;
			bool wasHit = false;

    }; // class Enemies

} // namespace game

#endif // ENEMIES_H_
