#include "enemies.h"

namespace game {

Enemies::Enemies(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture, int s) : SceneNode(name, geometry, material, texture) {
	health = 1000;
	state = 1;
	velocity_ = glm::vec3(0.0,0.0,0.0);
	target_ = NULL;
}


Enemies::~Enemies(){
}

glm::quat Enemies::GetAngM(void) const {

    return angm_;
}

SceneNode* Enemies::GetTarget(void) const {
	return target_;
}


void Enemies::SetAngM(glm::quat angm){

    angm_ = angm;
}

void Enemies::SetTarget(SceneNode* target) {
	target_ = target;
}

//Health
float Enemies::getHealth() {
	return health;
}

void Enemies::setHealth(float x) {
	health = x;
}

//Was hit flag
bool Enemies::enemyHit() {
	return wasHit;
}
void Enemies::setEnemyHit(bool r) {
	wasHit = r;
}


void Enemies::Update() {

	// ENEMY STATE LOGIC
		//Target is the state when the enemy is within a certain range of the player or was hit by a bullet
	if (glm::distance(position_, target_->GetPosition()) < 20
		|| wasHit) {
		state = 1;
	}
	else {
		//Wander is default state
		state = 3;
	}

	//Flee is the state when the enemy is at low hp
	if (health <= 250) {
		state = 2;
	}

	//Dead state means the enemy has no hp left
	if (health <= 0) {
		state = 4;
		display = false;
	}

	// END ENEMY STATE LOGIC

	//ENEMY STEERING BEHAVIORS
	if (state == 1 && target_) {
		// Target
		velocity_ = glm::vec3(
			glm::normalize(target_->GetPosition().x - position_.x) * 0.007,
			0.0,
			glm::normalize(target_->GetPosition().z - position_.z) * 0.007
		);
	}
	else if (state == 2 && target_) {
		// Flee
		velocity_ = glm::vec3(
			glm::normalize(position_.x - target_->GetPosition().x) * 0.007,
			0.0,
			glm::normalize(position_.z - target_->GetPosition().z) * 0.007
		);
	}
	else if (state == 3) {
		//Wander WIP
		velocity_ = glm::vec3(
			0,
			0,
			0
		);
	}
	else {
		//Dead WIP
		std::cout << "DEAD" << std::endl;
		velocity_ = glm::vec3(
			0,
			0,
			0
		);
	}
	// END ENEMY STEERING BEHAVIORS

	//std::cout << GetPosition().x << ", " << GetPosition().z << std::endl;
	std::cout << "Enemy Health: " << health << std::endl;
	position_.x += velocity_.x;
	position_.z += velocity_.z;


	Rotate(angm_);
}



} // namespace game

