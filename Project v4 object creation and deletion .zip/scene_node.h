#ifndef SCENE_NODE_H_
#define SCENE_NODE_H_

#include <string>
#include <vector>
#include <iostream>
#include <map>
#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#define GLM_FORCE_RADIANS
#include <glm/gtc/quaternion.hpp>

#include "resource.h"
#include "camera.h"


namespace game {

    // Class that manages one object in a scene 
    class SceneNode {

        public:
            // Create scene node from given resources
            SceneNode(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture = NULL);
			SceneNode(const SceneNode &nodeCpy);
            // Destructor
            ~SceneNode();
            
            // Get name of node
            const std::string GetName(void) const;

            // Get node attributes
            glm::vec3 GetPosition(void) const;
			glm::vec3 GetVelocity(void) const;
            glm::quat GetOrientation(void) const;
			glm::vec3 GetOrbit(void) const;
            glm::vec3 GetScale(void) const;
			SceneNode *GetParent(void);
			glm::mat4 GetHierarchy();
			glm::vec3 GetForward(void) const;
			glm::vec3 GetSide(void) const;
			glm::vec3 GetUp(void) const;
			bool GetVisibility(void) const;

            // Set node attributes
            void SetPosition(glm::vec3 position);
			void SetVelocity(glm::vec3 v);
            void SetOrientation(glm::quat orientation);
			void SetOrbit(glm::vec3 orbit);
            void SetScale(glm::vec3 scale);
			void SetParent(SceneNode *parent);
			void SetVisibility(bool visible);
			void Pitch(float angle);
			void Yaw(float angle);
			void Roll(float angle);
            
            // Perform transformations on node
            void Translate(glm::vec3 trans);
            void Rotate(glm::quat rot);
            void Scale(glm::vec3 scale);

            // Draw the node according to scene parameters in 'camera'
            // variable
            virtual void Draw(Camera *camera);
			// Change material for drawing
			void ChangeMaterial(Resource *material);

            // Update the node
            virtual void Update(void);

			// Node children
			// Add an already-created node
			void AddNode(SceneNode *node);
			// Find a scene node with a specific name
			SceneNode *GetNode(std::string node_name);

            // OpenGL variables
            GLenum GetMode(void) const;
            GLuint GetArrayBuffer(void) const;
            GLuint GetElementArrayBuffer(void) const;
            GLsizei GetSize(void) const;
            GLuint GetMaterial(void) const;

			//
			void setState(int x);
			int getState();

		protected:
			int state; //state of the node
			std::string name_; // Name of the scene node
			GLuint material_; // Reference to shader program
			GLuint texture_; // Reference to texture resource
			GLenum mode_; // Type of geometry
			GLuint array_buffer_; // References to geometry: vertex and array buffers
			GLuint element_array_buffer_;
			GLsizei size_; // Number of primitives in geometry
			glm::vec3 forward_; // Initial forward vector
			glm::vec3 side_; // Initial side vector
			glm::vec3 position_; // Position of node
			glm::vec3 velocity_; //Velocity of node
			glm::quat orientation_; // Orientation of node
			glm::vec3 orbit_; // Orbital offset of node
			glm::vec3 scale_; // Scale of node
			SceneNode *parent_;
			bool display = true; //display boolean

        private:
			
			// Scene nodes to render
			std::vector<SceneNode *> node_;

			

            // Set matrices that transform the node in a shader program
            void SetupShader(GLuint program);

    }; // class SceneNode

} // namespace game

#endif // SCENE_NODE_H_
