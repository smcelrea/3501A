#include "projectiles.h"

namespace game {

Projectile::Projectile(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture, SceneNode *s) : SceneNode(name, geometry, material, texture) {
	shooter = s;
	duration = 0;
	shoot = false;
}


Projectile::~Projectile(){
}

int Projectile::getDuration() {
	return duration;
}

void Projectile::setDuration(int x) {
	duration = x;
}

bool Projectile::getShoot() {
	return shoot;
}

void Projectile::setShoot(bool b) {
	shoot = b;
}

glm::quat Projectile::GetAngM(void) const {

    return angm_;
}


void Projectile::SetAngM(glm::quat angm){

    angm_ = angm;
}


void Projectile::Update(void){
	//std::cout << GetVelocity().x << ", " << GetVelocity().z << std::endl;
	//std::cout << position_.x << ", " << position_.y << std::endl;
	//std::cout << duration << std::endl;
	if (shoot) {
		duration++;
		position_ += velocity_;
		velocity_.y -= 0.0002;
	}

	if (duration >= 500) {
		reset();
	}

	// keep upright code
	// courteousy of
	// https://answers.unity.com/questions/821033/make-my-objects-rotation-upright.html
	// https://stackoverflow.com/questions/1171849/finding-quaternion-representing-the-rotation-from-one-vector-to-another
	// https://glm.g-truc.net/0.9.4/api/a00153.html
	glm::vec3 upPosition = velocity_;
	glm::vec3 curUp = GetUp();
	glm::vec3 difference = glm::cross(curUp, upPosition);

	glm::quat upright;
	upright.x = difference.x; upright.y = difference.y; upright.z = difference.z;
	upright.w = sqrt(std::pow(glm::length(curUp), 2) * std::pow(glm::length(upPosition), 2)) + glm::dot(curUp, upPosition);
	upright *= orientation_;
	upright = glm::normalize(upright);

	orientation_ = glm::normalize(glm::slerp(orientation_, upright, 0.5f));
    Rotate(angm_);
}

//Simple function that resets the bullet
void Projectile::reset() {
	shoot = false;
	duration = 0;
	position_ = glm::vec3(0.0, 50.0, 0.0);
}
            
} // namespace game
