Up arrow to shoot


Resources:

	Crumpled:
	https://freestocktextures.com/texture/shiny-silver-metallic-paper,1038.html

	Skybox:
	https://tf2maps.net/threads/sky_sunset_04-sky_iron_04.23416/

	Cockpit:
	http://www.aljanh.net/the-cockpit-of-a-spaceship-wallpapers/3634880787.html