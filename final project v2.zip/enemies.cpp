#include "enemies.h"

namespace game {

Enemies::Enemies(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture, int s) : SceneNode(name, geometry, material, texture) {
	health = 100;
	position = glm::vec3(0.0, 0.5, 0.0);
	velocity = glm::vec3(0.0, 0.0, 0.0);
	acceleration = glm::vec3(0.02, 0.0, 0.0);
}


Enemies::~Enemies(){
}


glm::quat Enemies::GetAngM(void) const {

    return angm_;
}


void Enemies::SetAngM(glm::quat angm){

    angm_ = angm;
}


void Enemies::Update(void){
    Rotate(angm_);
}

void Enemies::setState(int x) {
	state = x;
}

int Enemies::getState() {
	return state;
}

} // namespace game

