#include "projectiles.h"

namespace game {

Projectile::Projectile(const std::string name, const Resource *geometry, const Resource *material, const Resource *texture, SceneNode *s) : SceneNode(name, geometry, material, texture) {
	shooter = s;
	duration = 0;
	shoot = false;
}


Projectile::~Projectile(){
}

int Projectile::getDuration() {
	return duration;
}

void Projectile::setDuration(int x) {
	duration = x;
}

bool Projectile::getShoot() {
	return shoot;
}

void Projectile::setShoot(bool b) {
	shoot = b;
}

glm::quat Projectile::GetAngM(void) const {

    return angm_;
}


void Projectile::SetAngM(glm::quat angm){

    angm_ = angm;
}


void Projectile::Update(void){
	//std::cout << GetVelocity().x << ", " << GetVelocity().z << std::endl;
	//std::cout << position_.x << ", " << position_.y << std::endl;
	//std::cout << duration << std::endl;
	if (shoot) {
		duration++;
		position_ += velocity_;
	}

	if (duration >= 500) {
		reset();
	}
    Rotate(angm_);
}

//Simple function that resets the bullet
void Projectile::reset() {
	shoot = false;
	duration = 0;
	position_ = glm::vec3(0.0, 50.0, 0.0);
}
            
} // namespace game
